/*Que cuando se escribe el supermercado se de un autocompletar, que también tome en cuenta las mayúsculas
Que se evite que esté vacío y que no hayan números el campo de input y cuidado con las tildes cuando se de agregar.
Que se asocie esta palabra con una imagen del logo en total van a ser 6 imágenes (Mercadona, Lidl, Carrefour, Ahorramas, Dia y Otros y lo imprima en la tabla.
Que se vayan agregando hacia abajo los supermercados 
Finalmente que la tabla se limite a 3 columnas.*/

function supermercados(){

	let supermercado = document.getElementById('supermercado').value;

	//crear contenedor
	let contenedor = document.getElementById('contenedor');
	

	//crear filas
	//for(i = 0; i < 1; i++){
		let caja = document.createElement("div");
		caja.classList.add('caja');

		//crear celdas
		for (var j = 0; j < 1; j++) {
			let cuadro = document.createElement("div");
			cuadro.classList.add('img-wrap');
			cuadro.innerText = supermercado

			let cerrar = document.createElement("span");
			cerrar.classList.add('close');
			cerrar.innerText = "x";
			cerrar.onclick = function borrar(ev){
				console.log(ev); //ev es el propio evento, y en él está la información
				console.log(ev.target); //el target será el bloque pulsado
				if (window.confirm("se va a eliminar")){
				ev.target.remove();
				}
			};
			let logo = document.createElement('img');
			logo.classList.add('logosupermercados');
	

			cuadro.appendChild(logo);
			cuadro.appendChild(cerrar);
			caja.appendChild(cuadro);
		}

		
		contenedor.appendChild(caja);
	//}


}


/*function borrar(el){
	var element = el;
	if (window.confirm("se va a eliminar")){
		element.parentNode.remove();
		}
}*/