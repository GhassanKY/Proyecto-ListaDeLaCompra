// Informacion de las fechas/horas/dias/meses
const dateNumber = document.getElementById('dateNumber');
const dateText = document.getElementById('dateText');
const dateMonth = document.getElementById('dateMonth');
const dateYear = document.getElementById('dateYear');



// Contenedor de dia/semana/mes/año

const productContainer = document.getElementById('tasksContainer');

const setDate = () => {
    const date = new Date();
    dateNumber.textContent = date.toLocaleString('es', { day: 'numeric' });
    dateText.textContent = date.toLocaleString('es', { weekday: 'long' });
    dateMonth.textContent = date.toLocaleString('es', { month: 'short' });
    dateYear.textContent = date.toLocaleString('es', { year: 'numeric' });
};
// Contenedor de dia/semana/mes/año



//Agregar una nueva tarea       //Agregar una nueva tarea               

const addNewTask = event => {
    event.preventDefault();
    var { value } = event.target.taskText;
    NombreProducto.push(taskText.value)
    if (!value) return;
    const product = document.createElement('div');
    product.classList.add('task', 'roundBorder');
    product.innerText = value;
    product.id = value;
    product.onclick = function(ev){
        console.log(ev.target)
         }
    productContainer.prepend(product);
    event.target.reset();

//Agregar una nueva tarea       //Agregar una nueva tarea        




//Boton de Cerrar             //Boton de Cerrar 

    let cerrar = document.createElement("span");
    cerrar.innerText = "x";
    cerrar.classList.add('close')
    cerrar.onclick = function borrar(ev) {
        console.log(ev)
        console.log(ev.target);
        if (window.confirm("Se va a eliminar")) {
            ev.target.parentNode.remove();
        }

    }
    product.appendChild(cerrar)

//Boton de Cerrar     //Boton de Cerrar   






//Checkbox a un lado del texto (cambia de color)      

    let checkboxColor = document.createElement("input")
    checkboxColor.setAttribute("type", "checkbox");
    checkboxColor.addEventListener('click', changeTaskState)
    checkboxColor.addEventListener('click', renderOrderedTasks)
    product.prepend(checkboxColor);

//Checkbox a un lado del texto (cambia de color)     






//Abajo se encuentra la funcion del multi selector   

    const Form = document.createElement("form")
    Form.classList.add("Form-Center")
    product.appendChild(Form)
    let Multiselect = document.createElement("div")
    Multiselect.classList.add("multiselect")
    Form.appendChild(Multiselect)
    let Selectbox = document.createElement("div")
    Selectbox.classList.add("selectBox")
    Multiselect.appendChild(Selectbox)
    let select = document.createElement("select")
    select.setAttribute("disabled", true)
    addSelectOptions(Mercado, select)
    let Sobreseleccionado = document.createElement("div")
    Sobreseleccionado.classList.add("overselect")
    Multiselect.appendChild(Sobreseleccionado)
    Selectbox.appendChild(select)
    Selectbox.addEventListener("click", () => {
        if (!expanded) {
            Checkboxes.style.display = "flex";
            expanded = true;
        } else {
            Checkboxes.style.display = "none";
            expanded = false;

        }
    })


    //Checkboxes


    const Checkboxes = document.createElement('div')
    Checkboxes.classList.add("checkboxes")
    Multiselect.appendChild(Checkboxes)
    for (i = 0; i < Supermercados.length; i++) {
        let label = document.createElement("label")
        label.innerText = Supermercados[i];
        label.setAttribute("for", Supermercados[i])
        let input = document.createElement("input")
        input.classList.add("input")
        input.setAttribute("type", "checkbox",)
        input.id = Supermercados[i]
        input.value = Supermercados[i] 
        Checkboxes.appendChild(label)
        Checkboxes.appendChild(input)

    }
};


var Supermercados = ["Mercadona", "Lidl", "AhorraMas", "Carrefour", "Dia"]

var expanded = false;

//Fin del Multiselect




//Dentro de este recuadro se encuentra Lista Ordenada/Cambio de color y Orden

const changeTaskState = event => {
    event.target.parentNode.classList.toggle('done');
};

const order = () => {
    const done = [];
    const toDo = [];
    productContainer.childNodes.forEach(el => {
        el.classList.contains('done') ? done.push(el) : toDo.push(el)
    })
    return [...toDo, ...done];
}

const renderOrderedTasks = () => {
    order().forEach(el => productContainer.appendChild(el))
}

//Dentro de este recuadro se encuentra Lista Ordenada/Cambio de color y Orden




//Se agrega al selector informacion

function addSelectOptions(array, select) {
    for (var i = 0; i < array.length; i++) {
        var option = document.createElement("option");
        option.id = 
        option.value = array[i];
        option.text = array[i];
        select.add(option)
    }
}
var Mercado = ["Elige una Tienda"]

//Se agrega al selector informacion 



function ConstructorMercado(nombreSuper, producto) {
    var producto = {
        'nombreSuper': nombreSuper,
        'producto': producto
    }
}

// Filtro por nombre

const NombreProducto = []
const NombreMercado = []

console.log(NombreProducto)

var SelectFiltro = document.getElementById('NombreSelect')
for (i = 0; i < Supermercados.length; i++) {
    var opciones = document.createElement("option")
    opciones.innerText = Supermercados[i]
    SelectFiltro.appendChild(opciones)
    SelectFiltro.onchange = Filtro
    
}

function Filtro (Servicio){
const ValorSelect = SelectFiltro.value
console.log(ValorSelect)
const productos = Servicio.filter(item => item.nombre === SelectFiltro.value);
console.log(productos)
for (i = 0; i < productos.length; i++){
    const filtroProducto = document.createElement('div')
    filtroProducto.classList.add('task', 'roundBorder');
    productos.innerText  

}
}

listaProductos = []
function crearProducto(ev){
    var Super = []
    var IdDiv = ev.target

    
    var NuevoProducto = {
        "nombre": IdDiv.id,
        "supermercado": Super
    }
listaProductos.push(NuevoProducto)
}


